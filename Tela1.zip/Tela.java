import javax.swing.JFrame;

public class Tela
{
	public static void main(String[] args)
	{
			Tela1 t = new Tela1();
			t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
			t.setSize(500,650);
			t.setLocationRelativeTo(null);
			t.setVisible(true);
	}
}
